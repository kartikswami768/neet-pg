---
title: "Elite Ophthalmology — Anatomy & Foundations (pp. 6–30)"
source: "Elite Ophthalmology PDF"
subject: Ophthalmology
tags:
  - ophthalmology
  - anatomy
  - embryology
  - investigations
  - refractive-error
---

# ANATOMY OF EYE:

- Volume of orbital cavity = 30 ml
- Eyeball / Globe → Volume = 6 ml

![[assets/p06-eom-attachments.jpg]]

- 7 attachment = 6 muscle + 1 optic nerve
- Removal of attachment = Enucleation

7 attachment →
- M.R
- L.R
- S.R
- I.R
- S.O
- I.O
- Optic Nerve

→ six EOM

![[assets/p06-eye-cross-section.jpg]]

The shape of the eyeball is a sphere
Volume = 6 ml
weight = 7 gm
Circumference = 7.5 cm

# Layers of Eyeball

1) **Outer fibrous layer**
   - Cornea → Ant: 1/6th
   - Sclera → Post: 5/6th
   - They are thick & strong to sustain the IOP

- Junction b/w cornea & sclera → **Limbus**

2) **Middle vascular layer** → Uveal layer
   - Iris → ciliary body → choroid
   - Ant. → Post.

- Junction b/w ciliary body and Choroid → **ORA SERATA**
  - b/w Pars Plana & choroid
  - Pars Plicata → 60–70 ciliary processes
  - Pars Plana

- Point of attachment of ciliary body to sclera → **scleral spur**

![[assets/p07-ciliary-body-lens-sketch.jpg]]

3) **Inner most layer** → neural layer → **Retina**
From Ora Serata → optic disc

![[assets/p07-sectional-anatomy-eye.jpg]]

# Segment of the Eyeball

**Anterior Segment** → Anterior to posterior part of lens

- Ant. Chamber
  - From Post. part of cornea till iris, lens & diaphragm
- Post. Chamber
  - Iris to post. part of lens

> Lens situated in the posterior chamber of the anterior segment

Content → Aqueous Humour

- AC = 0.25 ml
- PC = 0.05 ml
- Total = 0.3 ml

- Filtrate of plasma formed from the ciliary process (60–80%)
- Rate of formation → **2–2.5 μl/min**

- Formed by 3 process →
  1. Secretion → Maxm. Active process, ATP required (70%)
  2. Diffusion → 20%, passive process, No ATP required
  3. Ultrafiltration → 10%, passive process, No ATP required

> Aqueous humour formed in the posterior chamber of the anterior segment

![[assets/p08-aqueous-drainage.jpg]]

# Three way of drainage

### 1) Trabecular Outflow = 90%

→ **0.22 – 0.28 ml/min/mmHg**

Post. chamber → pupil → Trabecular meshwork → Schlemm’s Canal → Aqueous / conjunctival vein → episcleral vein

# Type of Trabecular meshwork:

i) Corneoscleral
ii) Uveal
iii) Juxta canalicular

> Maximum resistance to flow of aqueous → at Juxta canalicular trabecular meshwork (close to Schlemm’s canal)

To release resistance in Glaucoma → Trabeculectomy

### 2) Uveoscleral outflow = 10%

Drain → **Post-ciliary vessels** → choroid → supra choroid space → sclera

### 3) Uveovortex outflow = minimal %

Drain → **Vortex Vein**

# Posterior segment

→ Post to posterior part of lens

Content → Vitreous Humour
Volume → **~4 ml**

| AQUEOUS | PLASMA | VITREOUS |
|---|---|---|
| 1) 99% water |  | 1) 99% water |
| 2) Lactate, Ascorbate & chlorine more in aqueous than plasma |  | 2) Collagen, Hyaluronic acid & Ascorbate are more in vitreous compared to plasma; else is less compared to plasma |

- Else is less compared to plasma

![[assets/p09-blood-aqueous-barrier.jpg]]

**Blood aqueous Barrier**

§ formed by tight junction of iris endothelium & ciliary non pigmented epithelium §
fx: prevent plasma protein in entering aqueous.

**Pathology:** Uveitis → Inflammation in eye
↓
Blood aqueous barrier broken down
↓
**FLARE** → Leakage of protein in Aqueous

![[assets/p09-barrier-inflammation-micrograph.jpg]]

> During inflammation, the blood barrier gets broken down

3) Gel like → d/t collagen
**COLLAGEN II (MC), VI, IX, XI**

# Attachment of vitreous

- **ora serrata** {strongest attachment?}
- fovea
- optic disc
- patellar fossa & Weigert’s ligament

![[assets/p09-vitreous-attachment.jpg]]

Weighert ligament → surround {strong in children} the patellar fossa

- When we age → gel vitreous collapse
- K/a **SYNERESIS**

- Posterior vitreous collapse first
- detachment from retina → may cause retinal tear or hole

→ post-vitreous detachment

**Liquified vitreous** → **SYNCHISIS** → enters retinal hole
↓
**RETINAL DETACHMENT & Rhegmatogenous**

- Entire vitreous collapsing
  - Seen as a Ring → **WEISS RING**
  - s/o complete PVD

![[assets/p10-syneresis.jpg]]

![[assets/p10-weiss-ring.jpg]]

# Symptoms:

1) Scotoma → Floater & visual field defect
   - Single
   - Old age
   - Positive scotoma

+ Negative Scotoma
Eg.: Blind Spot

![[assets/p10-scotoma.jpg]]

![[assets/p11-sclera-conjunctiva-section.jpg]]

**Sclera** ⇒ post. 5/6th
- made of collagen
- white & opaque
- Haphazard arrangement of collagen fibres

**Cornea** ⇒ 1/6th Anterior
- Transparent
- Regular arrangement of collagen fibres

**Conjunctiva**

# Anatomy of Conjunctiva

![[assets/p11-conjunctiva-parts.jpg]]

# Parts of Conjunctiva

1. Palpebral conjunctiva
2. Forniceal conjunctiva
3. Bulbar Conjunctiva

# Extra Ocular Muscle:

No.: Six
Origin: Apex of orbit
except → **Inferior Oblique**

# Orbit:

Shape: Pyramid
Volume: 30 ml

![[assets/p12-orbit-pyramid.jpg]]

# Lesser Wing of sphenoid

![[assets/p12-orbit-bones.jpg]]

- 7 bones present in the orbit
- Medial wall thinnest → Lamina Papyracea (Thinnest bone → Ethmoidal bone)
  - Children = Ethmoidal sinus → MC of orbital cellulitis in children
- Weakest wall / MC wall to # → Floor of orbit d/t infraorbitalis groove.
- Lateral wall strongest & thickest
- Weakest point of orbit → Posteromedial aspect of maxillary bone in floor
- Blunt trauma → floor # or Blow out #

- Xray sign → Tear drop sign (Waters view)
- enophthalmos
- Inferior rectus can get entrapped in this #
  - → Difficulty to look up

**HYPO-ESTHESIA or ANAESTHESIA OF IPSILATERAL CHEEK**

![[assets/p13-orbital-angle.jpg]]

Eyeball & orbit are at 23°

3 gap b/w orbit and brain →

1. **Optic canal**
   - optic n. and ophthalmic artery
   - gap of lesser wing of sphenoid

2. **Superior orbital fissure**
   - gap b/w lesser and greater wing of sphenoid

3. **Inferior orbital fissure**
   - Maxillary Bone & Zygomatic

**Infra Orbital fissure**
→ @ floor of orbit
→ contains the infra orbital N.

↓

Branch of Maxillary division of Vth Nerve (V2)
↓
Sensation of cheek.

![[assets/p13-infraorbital-canal.jpg]]

# Relations of Orbit:

![[assets/p14-orbit-relations.jpg]]

Volume of orbit = 30 ml
Eyeball = 6.5 ml
} orbital fat
major component of orbit

# Component of orbit:

1. Eyeball
2. Optic Nerve
3. Orbital fat
4. EOMs
5. Cranial Nerve
6. Vessels
7. Ciliary Ganglion
8. Lacrimal glands & sacs

# Sphenoidal Bone

- Greater wing
- Lesser wing
- Body of sphenoid

Structure passing through optic foramen:

1. Optic Nerve
2. Ophthalmic Artery

![[assets/p14-sphenoid-anterior-view.jpg]]

![[assets/p14-orbital-apex.jpg]]

# Sensory Supply of the eye:

**Ophthalmic Nerve** ← 1st Branch of Trigeminal N.

i) Lacrimal Nerve → **Lacrimal Gland**
- Conjunctiva
- Lateral eyelid

ii) Frontal Nerve →
- Conjunctiva
- Eyelid
- Part of Forehead

iii) Nasociliary →
- long ciliary N. →
  - Cornea
  - Ciliary body
  - Iris
- Infra Trochlear N. →
  - Conjunctiva
  - **Lacrimal sac**
  - Caruncle
  - Medial part of the eyelids

# Tarsal Plates:

![[assets/p15-tarsal-plates.jpg]]

- Tarsal plates are firm, dense plates of **Connective tissue** & fibrous tissue?
- Check ligament of the lateral rectus is attached to **Whitnall’s tubercle**

**Whitnall’s Tubercle** → small elevation on the orbital surface of the zygomatic bone, just within the lateral orbital margin.

structure attached to it:

1. Check ligament of lateral rectus
2. Lockwood’s ligament {suspensory ligament of the eyeball}
3. Lateral palpebral ligament.

4) Lateral horn of the levator aponeurosis

| | Eyeball of Newborn | Adult |
|---|---|---|
| Size (Axial length) | 16.5 mm (small eyed Hypermetropia) → +2.5D | 24 mm |
| Corneal diameter | 10 mm | 12 mm |
| Lens shape | Spherical | Biconcave |
| Orbital Angle | 50° → Divergent orbit | 45° |
| Visual Acuity | < 6/60 | 6/6 |

- Adult size attained @ 14yr → Emmetropisation
- Fovea not completely formed & only after 3 months fully develops
- # BSV upto 3 months
- Refractive error of +2.5D
- 6/6 attained @ 6 yrs

# Children Milestone:

1) **Fixation** → see object continuously from one eye
   - 6wks = starts developing, completed by 3–6months
   - monocular phenomenon.

2) **Fusion** → Binocular phenomenon
   - See object using both eye
   - 6 months = developed, stereopsis starts developing
   - (3D vision)

3) **Stereopsis** → Binocular phenomenon
   - 6 year = fully developed

# Embryology of Eye:

- **Surface Ectoderm**:
  - S → skin of eyelids / appendages
  - L → Lens
  - L → Lacrimal Apparatus
  - E → Epithelium of cornea / conjunctiva.

# Neuroectoderm / optic cup

R → Retina
- Outer lip = RPE (C10th layer)
- **Subretinal Space**
- Inner lip = Neurosensory → All 9 layers retina

O → Optic stalk / Optic Nerve

M → Muscles of Iris (Sphincter Pupillae, Dilator Pupillae)

E → Epithelium of Iris / Ciliary Body

# Neural Crest:

| Neural | Mesenchymal |
|---|---|
| Optic nerve covering | Cornea except epithelium |
| Myelin sheath | Sclera except epithelium |
| Ciliary ganglion | Orbital bones |
| Melanocytes | Trabecular meshwork |
|  | Schlemm’s canal |
|  | Ciliary Body muscle |
|  | Iris / Ciliary Body stroma |
|  | Tendons of EOM |

> Myelin sheath of O.N formed by Oligodendrocytes

- Mesoderm
  1. Choroid
  2. Hyaloid Artery (C10 vitreous)
  3. Belly of E.O.M
  4. Temporal portion of sclera

![[assets/p17-eom-tendon-belly.jpg]]

# Period after conception — Major milestone

| Period after conception | Major milestone |
|---|---|
| 3 wk | Optic groove appears |
| 4th wk | Optic pit develops into optic vesicle; Lens plate forms; Embryonic fissure develops |
| 1st month | Lens pit develops, followed by formation of the lens vesicle; Hyaloid vessels develop |
| 4th month | Formation of retinal vasculature begins; Hyaloid vessels regress; **Canal Schlemm**; Formation of physiological optic disc cup and **Lamina Cribrosa** |

### 5th month

- Bowmen’s membrane develop
- Formation of the major arterial circle and sphincter muscle of the iris
- Photoreceptors differentiate
- Eyelid separation begins

> 3rd wk / 22nd day of IUL

![[assets/p18-embryology-forebrain-optic-vesicle.jpg]]

**Optic Vesicle**
gene: PAX-6
↓
Diencephalon
↓
Prosencephalon

![[assets/p18-brain-vesicles.jpg]]

![[assets/p18-lens-placode-optic-stalk.jpg]]

![[assets/p18-optic-cup-cross-section.jpg]]

# Peter’s Anomaly:

- where lens vesicle don’t detach properly from the surface ectoderm
- lens have attachment to the corneal / conjunctival epithelium → corneal opacity

![[assets/p19-infant-peters-anomaly.jpg]]

- D/D for Hazy cornea @ birth.
- MC congenital cause for **penetrating keratoplasty** in children
  ↓
- Full thickness corneal transplant

# Lacrimal gland (main)

![[assets/p19-lacrimal-gland-diagram.jpg]]

**LID GLANDS**
1. Glands of Moll
2. Meibomian gland
3. Gland of Zeis

**LACRIMAL GLANDS**
1. Krause
2. Goblet cells
3. Henle
4. Wolfring
5. Manz

# Hyaloid Artery

![[assets/p19-hyaloid-tunica-vs-lentis.jpg]]

# Remnants of Hyaloid Artery

1. Muscae Volitans
2. Mittendorf’s dot
3. Bergmeister Papilla

![[assets/p20-phpv-histology.png]]

# Persistent Hyperplastic 1° vitreous (PHPV)

- Poor prognosis
  a/w
  1. U/L
  2. Micro-ophthalmus
  3. Cataract (attachment to lens)
  4. Retinal detachment (attachment to lens)
  5. Vitreous H'mage

- **PATAU SYNDROME (Trisomy 13)**

# Muscae Voliantes {clouds}?

- Debris of hyaloid vessels in vitreous
- Multiple floaters
- **Positive scotoma**

# Mitten Dorf dot

→ Ant. segment of Hyaloid vessels attached to lens.
→ asymptomatic
→ Good prognosis

![[assets/p20-muscae-volitantes.jpg]]

![[assets/p20-mittendorf-dot.jpg]]

# Bergmister Papilla

→ Remnant of Hyaloid vessels post segment
→ Asymptomatic
→ Good prognosis

![[assets/p20-bergmeister-papilla.jpg]]

# Neuroectoderm development

![[assets/p21-neuroectoderm-development.jpg]]

1) Retina →
   - RPE from outer lip of optic cup
   - Neurosensory retina from inner lip of optic cup of all 9 layers.

2) Optic Nerve

3) Ciliary Epithelium

4) Iris Epithelium

5) Sphincture Epithelium

6) Dilar Papilla

7) Zonules (3° vitreous)

8) Vitreous (2° vitreous)

# COLOBOMA:

- Embryonic fissure fuses @ 36days / 5wk of gestation → (N)
- Failure of closure → **COLOBOMA**
- MC location: Inferonasal

![[assets/p21-embryonic-fissure-diagram.jpg]]

# i) Coloboma of Optic disc

![[assets/p21-morning-glory-disc.jpg]]

### ii) Chorioretinal Coloboma

- can lead to Retinal detachment
- Rx: **BARRAGE LAZER** with 3 Layers of spot around the defect to prevent detachment.

![[assets/p22-chorioretinal-coloboma.jpg]]

### iii) Iris Coloboma:

- Pear shaped pupil / Tear shaped
- a/w lens subluxation → d/t weak zonules
- MC location is **internonasal quadrant**

![[assets/p22-iris-coloboma.jpg]]

# NEURAL CREST CELLS DERIVATIVES

![[assets/p22-neural-crest-derivatives.jpg]]

**Sclera** ⇒ **NCC + Mesoderm**

**EOMs** ⇒ **Mesoderm + NCC**

# Arrest / Failure of NCC migration:

**Congenital Horner’s Syndrome:** Sympathetic palsy & sympathetic stimuli required for migration of NCC migration?

1. Miosis
2. Mild ptosis
3. Enophthalmosis
4. Hypopigmented Iris → Pathognomic for congenital Horner’s
   {HETEROCHROMIA}

![[assets/p23-congenital-horner-heterochromia.jpg]]

# Neurocristopathies:

Inappropriate interaction b/w NCC & Neuroectoderm

# Congenital Aniridia:

- d/t to mutation in **PAX 6 gene**
- required for proper interaction b/w NCC and neuroectoderm

![[assets/p23-congenital-aniridia.jpg]]

# Axenfield Rieger → “AD”

- Anterior segment dysgenesis
- Eccentric Pupil {corectopia}
- Polycoria {Multiple Pupils}
- TM not well developed → developmental glaucoma
- Iris stroma dystrophy.

![[assets/p23-axenfeld-rieger.jpg]]

# BASIC INVESTIGATION:

1) Visual Acquity:

**SNELLEN’S CHART**

- pt @ 6m
- subjective test

**Minimal Angle of Resolution (MAR)**

↳ smaller the angle better is the vision

minimal angle & 6/6 = 1 minute of arc

**MAR = 1 / visual acuity**

- 6/60 → pt. seen only @ 6m
- 6/60 → N individual can see this @ 60m
- 6/36 → MAR = 6′ of arc
- 6/24 → MAR = 4′ of arc
- etc.

**Total angle → MAR × 5**

![[assets/p24-mar-e-chart.jpg]]

Angles subtended on post. surface of lens
→ **NODAL POINT**
→ <α

![[assets/p24-nodal-point.jpg]]

6/60 × → 5/60 × → 4/60 × → 3/60 × → 2/60 ×

**Counting fingers**
→ Hand movement → Perception of light → Projection of rays (which quadrant)

# 2) Slit lamp Examination

- See upto **Ant. 1/3rd of vitreous**
- Binocular test & use both eye → stereopsis 3D vision of eye
- Advantage: depth can be assessed

![[assets/p24-slit-lamp-photo.jpg]]

![[assets/p24-slit-lamp-diagram.jpg]]

# 3) Slit lamp Examination → slit lamp + lens

Gold standard to see → Optic disc
→ Macula & central Retina

# Lenses used in the investigation

- (+) -90D → see as Real inverted images
- (−) -58D → **Virtual erect image**

![[assets/p25-slit-lamp-biomicroscopy.jpg]]

# 4) Ophthalmoscope:

## a) Direct Ophthalmoscope (uniocular)

### i) Distant direct ophthalmoscope

→ uses:
1. Identify media opacity
2. Refractive error assessment (**BRUCKNER’S TEST**)
3. Patency of peripheral iridotomy.

- Doctor stands @ 25cm
- Ⓝ Reflex ⇒ RED { from vascular tissue choroid }

![[assets/p25-red-dot-iris.jpg]]

- white reflex (AbN) → Leucocoria

![[assets/p25-direct-red-reflex-photo.jpg]]

![[assets/p25-leukocoria.jpg]]

### ii) Direct Ophthalmoscopy

→ Doctor comes as close to the patient.

- visualise → Optic disc & Macula
- Uniocular test → No depth visualised {no stereopsis}
- **Virtual erect image**
- ® eye of doctor → ® eye of patient
- L eye of doctor → L eye of patient

![[assets/p25-direct-ophthalmoscopy-photo.jpg]]

**slit lamp microscopy:** Another method to look at the fundus

- Concave lens
- Convex lens

- **HRUBY LENS** → -58.6 D
- **non-contact** → +75 D, +90 D
- **contact** → Goldmann 3 mirror lens → +60 D

Adv: Magnification + Stereopsis

# b) Indirect Ophthalmoscopy / a.k.a Fundoscopy

- Binocular vision
- Condensing lens used ⇒ +20 D ; +30D
- Entire retina can be seen
- Real inverted images
- Done at arm distance from the patient
- Field of view ⇒ **8DD** area at one time
- Higher learning curve
- **Not influenced by refractive error**

| DIRECT OPHTHALMOSCOPE | INDIRECT OPHTHALMOSCOPE |
|---|---|
| 1) Uniocular vision | 1) Binocular vision |
| 2) Virtual erect image | 2) Real inverted image |
| 3) Visualise optic disc & macule | 3) Visualise Fundus & entire retina seen? |
| 4) Field of view: 2 Disc Diameter | 4) Field of view = 8DD [1DD = 1.5mm] |
| 5) Magnification: more | 5) Magnification: Less |
| 6) Depends on R.E of pt & doctor | 6) Does not depend on R.E |

M = Power of eye / Power of lens
= 60/4
= 15 times

Power of eye = +60D
of cornea = +44D
of lens = +16D

M = Power of eye / Power of lens
= 60 / 20 or 30
= 2–3 times

Power of Converging = Myopia > Emmetropia > Hypermetropia
(i.e >15 times)

eg.: -4D
= 64/4 = 16 times //

# Investigation based on Purkinje images:

- Corneal thickness = Pachymetry → I & II
- Corneal curvature = Keratometry ⇒ I
- Corneal surface = Plaisdo disc → I
- Corneal endothelium = Specular microscopy ⇒ II

> 2/3rd of refraction of light done by cornea

> R.I of cornea = 1.376
> R.I of air = 1.00

- Corneal surface = Plaudo disc → I
- Corneal endothelium = Specular microscopy ⇒ II

![[assets/p27-purkinje-images-ray-diagram.jpg]]

- [N] Thickness of lens in adult = 4mm
- Ant. Chamber depth b/w II & III = 2–3mm

> Purkinje image in **Aphakia** → Image III & IV are absent
>
> “ ” “ Mature cataract → Image IV Absent.

# Ultrasound:

- A-scan ⇒ tell axial length of eye
- B-scan ⇒ post. segment evaluation in case of media opacities; freq. 10 Mhz

# Refraction:

Bending of light when light passes through two media
Refraction of eye done by cornea & lens
{3/4th}  {1/4th}

Total refraction power of eye → +60D
" " " cornea → +44D
" " " lens → +16D

![[assets/p27-refraction-corneal-lens-ray.jpg]]

# Refractive Power, D ∝ 1/f (focal length)

# Refractive Power & Curvature:

![[assets/p28-curvature-diagrams.jpg]]

- flatter curvature
- steep curvature

D ∝ 1/f
D ∝ curvature

# Refractive Power vs. R.I:

**D ∝ μ**

## R.I of structure in Eye:

- Tears = 1.36
- Cornea = 1.376
- Lens cortex = 1.386
- **Lens nucleus = 1.406**
- Vitreous = 1.335
- Aqueous = 1.336
- Air = 1.00

> Max. refractive index → Lens nucleus
>
> Max. refraction → Tear film – air interface
> = 1.357 – 1.00
> = 0.357
> ⇒ Cornea

# Emmetropia:

![[assets/p28-emmetropia-ray-diagram.jpg]]

# Accommodation

= Process by which near objects are brought to focus on the retina by contraction of circular fibres of ciliary muscles.

# Near triad / Accommodation triad:

1) Convergence of both eyeballs → middle rectus → IIIrd N.
2) Miosis (to + depth of focus) → sphincture pupillae → parasympathetic supply of 3rd N.
3) ↑se in anterior curvature of lens → **Ciliary muscle** → parasympathetic supply by 3rd nerve.

![[assets/p29-accommodation-rest-and-near-triad.jpg]]

## At Rest

1. P > A curvature of lens
2. Zonules stretched & in tension
3. Anti-capsula is stretched
4. Equator diameter = 10mm.

## At Accommodation

1. ↑ sed diameter of ciliary ring
2. Relaxation of Zonules
3. Relaxation of Anterior Capsule
4. ↓sed equatorial diameter of lens
5. ↑sed anterior curvature of lens
   - & → forward bulging of anterior capsule?
6. Post Curvature of lens → same
7. ↑ Dioptre power of lens
8. Thickness of lens ↑sed
9. More spherical lens

→ ↑sed radius of curvature

For Accommodation:
1. Ciliary muscle tone
2. Elastic anterior capsule
3. Lens substance - mouldable

↓ old age

# PRESBYOPIA

Physiological loss of accommodation d/t aging

> Not Refractive Error

![[assets/p29-presbyopia-ray-diagram.jpg]]

Result in recession of puncta proxima (near point)

# Correction

↑D → ↓f

1) Convex lens
or positive spherical lens

![[assets/p30-presbyopia-correction-ray.jpg]]

2) **Progressive lens** [small sketch]

3) **Executive Bifocal** [small sketch labelled distant / near]

4) **Kryptok Bifocal** [small sketch labelled distant / near]

5) **Trifocal** [small sketch labelled distant / intermediate / near]

## NEET-PG

| Age | Power |
|---|---:|
| 40–45 yr | +1 D |
| 45–50 yrs | +1.5 D |
| 50–55 y | +2 D |
| 55–60 y | +2.5 D |

# 2) KAMRA INLAY

![[assets/p30-kamra-inlay.jpg]]

**Pinhole Mechanism** →
- ↓ aperture
- Eliminate peripheral ring
- **↓ [UNCLEAR] spherical aberration**
- ↑ses depth of focus

# 3) Cataract Patient:

IOL → multi-focal IOL for all distal
intermediate
near

} vision
