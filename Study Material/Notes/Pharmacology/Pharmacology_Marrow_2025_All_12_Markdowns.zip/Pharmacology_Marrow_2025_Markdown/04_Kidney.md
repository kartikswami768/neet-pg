---
title: "Drugs Acting on Kidney"
aliases:
  - "Renal Pharmacology"
  - "Diuretics"
subject: "Pharmacology"
section: "Drugs Acting on Kidney"
type: "study-notes"
source: "Marrow — World of Revision — Pharmacology (2025)"
tags:
  - pharmacology
  - kidney
  - renal
  - diuretics
  - vasopressin
---

# Drugs Acting on Kidney

## Diuretics

| Drug/class | MOA & site | Uses | Side effects |
|---|---|---|---|
| **Carbonic anhydrase inhibitors** | − Carbonic anhydrase in PCT | **Acetazolamide:** DOC for acute mountain sickness. **Acetazolamide/dichlorphenamide:** familial hypokalemic periodic paralysis | ↓K⁺; metabolic acidosis; renal stones; hypersensitivity (rash, BM suppression); ↑NH₃ → C/i in cirrhosis |
| **Loop diuretics** | − Na⁺/K⁺/2Cl⁻ pump in thick ascending limb | **Furosemide:** DOC for pulmonary edema. **Torsemide:** longest acting. **Bumetanide:** most potent. **Ethacrynic acid:** most ototoxic. Most effective drugs when GFR <40 | ↓K⁺; ↓Ca²⁺ (Rx of hypercalcemia); ototoxicity (C/i: aminoglycosides); metabolic alkalosis; ↓Mg²⁺; ↑uric acid; ↑glucose |
| **Thiazides** | − Na⁺/Cl⁻ cotransporter in DCT | DOC for: HTN with edema; nephrogenic DI; other edema (as add-on). **Chlorthalidone:** longest acting, preferred in HTN. **Indapamide:** predominantly hepatic excretion, used in HTN. **Metolazone:** effective in GFR <40 (add-on to furosemide) | ↓K⁺ (max); ↑S. Ca²⁺/↓U. Ca²⁺ → Rx of hypercalciuric renal stones (+ citrate to avoid stones); thiamine deficiency |
| **Potassium-sparing diuretics** | **Spironolactone/eplerenone:** − aldosterone. **Amiloride:** − ENaC in collecting duct | Spironolactone/eplerenone DOC for cirrhotic edema (+ loop diuretic), resistant HTN. Amiloride DOC for lithium-induced DI, Liddle syndrome; used in cystic fibrosis | ↑K⁺; metabolic acidosis; spironolactone: gynaecomastia |
| **Osmotic diuretics** | Solute free water loss: PCT & loop | **Mannitol (Mnemonic: ABCDE):** acute congestive glaucoma (DOC); braking of diuretics (resistant); cerebral edema (DOC); dialysis disequilibrium (DOC); expected renal failure | ↓/↑Na⁺; ↓/↑K⁺; pulmonary edema; C/i in renal failure |

## Vasopressin Related Drugs

> **Note:** Terlipressin > octreotide for Rx of acute variceal bleed as it ↓mortality.

| Drug | Uses | Side effects |
|---|---|---|
| **Vasopressin antagonist:** Conivaptan (IV), Tolvaptan, Mozavaptan (IV emergency; oral long-term Rx) | **SIADH:** 3rd line vasopressin antagonists. TOC: free H₂O restriction (1st line); saline infusion (2nd line) | Hypokalemia; hepatotoxicity (tolvaptan) |
| **Vasopressin analogs:** Vasopressin | — | — |
| **Terlipressin** | DOC in acute variceal bleed | — |
| **Desmopressin** | DOC in: central DI; nocturnal enuresis; VW disease; hemophilia A | — |

**Desmopressin:** oral.
