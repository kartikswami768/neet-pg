---
title: "Drugs Acting on Autonomic Nervous System"
aliases:
  - "Autonomic Nervous System"
  - "ANS Pharmacology"
subject: "Pharmacology"
section: "Drugs Acting on Autonomic Nervous System"
type: "study-notes"
source: "Marrow — World of Revision — Pharmacology (2025)"
tags:
  - pharmacology
  - autonomic-nervous-system
  - ANS
  - cholinergic
  - adrenergic
---

# Drugs Acting on Autonomic Nervous System

## Regulation of ANS

|  | Parasympathetic NS | Sympathetic NS |
|---|---|---|
| **Receptors** | Muscarinic (M/c: M₃) or nicotinic | α or β |
| **Neurotransmitter** | Acetylcholine (ACh) | Norepinephrine (NE) |
| **Exceptions** | ACh in adrenals & sweat glands | Dopamine → D₁ in renal blood vessels → vasodilation (diuresis) |

## Neurotransmitters of ANS

### Acetylcholine (ACh)

**Drugs ↓ing ACh → neuromuscular toxicity (breathing difficulties).**

![Acetylcholine neurotransmitter diagram](assets/ANS_Acetylcholine_neurotransmitter.png)

### NE/Dopamine (DA)

![NE/Dopamine neurotransmitter diagram](assets/ANS_NE_Dopamine_neurotransmitter.png)

**Drugs affecting NE/DA:**

- VMAT-2 inhibitors:
  - **Tetrabenazine:** DOC for tics a/w Tourette syndrome; Huntington’s chorea.
  - **Deutetrabenazine, Valbenazine:** DOC for tardive dyskinesia (longer acting).
- Cocaine:
  - ↑DA → binds D₂ receptor → euphoria.
  - ↑NE → presents with hypertensive emergency (Rx: IV nicardipine).
  - **DOC for cocaine dependence:** Bromocriptine (D₂ +).

## Systemic ANS Drugs Action

### CNS

| Parasympathomimetic | Parasympatholytic | Sympathomimetic | Sympatholytic |
|---|---|---|---|
| ↑ Cognition | ↓ Cognition | — | Lipid-soluble β-blockers s/e: depression, insomnia, nightmares |
| Donepezil (DOC) in Alzheimer’s disease/dementia | Scopolamine: AKA truth serum for narcoanalysis (DOC: thiopentone) | — | — |

### Pupil

| Parasympathomimetic | Parasympatholytic | Sympathomimetic | Sympatholytic |
|---|---|---|---|
| **Active miosis** | **Passive mydriasis** | **Active mydriasis** | **Passive miosis** |
| Pilocarpine (DOC): closed-angle glaucoma | Tropicamide; atropine (1% ointment); homatropine; cyclopentolate | Phenylephrine; ephedrine | Phenoxybenzamine; prazosin |
|  | Ocular fundus exam; uveitis/corneal ulcers → prevent synechiae |  |  |
|  | C/i: closed-angle glaucoma → precipitates acute congestive glaucoma |  |  |
|  | Cycloplegic function: ↓iridocyclitis pain; refractive error testing: children → 1% atropine, adult → tropicamide drops |  | No cycloplegic function |

### Oro-pharyngeal secretions, bronchi, heart and bladder

| Organ/effect | Parasympathomimetic | Parasympatholytic | Sympathomimetic | Sympatholytic |
|---|---|---|---|---|
| **Oropharyngeal secretions** | ↑ | ↓ | — | — |
|  | Pilocarpine; **Cevimeline (DOC)** for xerostomia (Sjogren syndrome/sicca syndrome) | **Glycopyrrolate (DOC)** (does not cross BBB) > atropine as pre-anaesthetic medication (prevents aspiration) | — | — |
| **Bronchi** | Bronchoconstriction | Bronchodilatation (M₃ −) | Bronchodilatation (β₂ +) | Bronchoconstriction |
|  | C/i: bronchial asthma (BA) & COPD | For COPD: tiotropium (DOC); umeclidinium; revefenacin; aclidinium LAMA (BD); ipratropium SAMA (QID) | β₂ agonists (s/e: hyperglycemia): SABA—salbutamol, terbutaline, pirbuterol; LABA—formoterol, salmeterol; vLABA—olodaterol, vilanterol, carmoterol | β-blockers; C/i: bronchial asthma and COPD |
|  |  |  | SABA & formoterol are relievers (fast acting) |  |
| **Heart** | ↓HR; ↓AV conduction | ↑HR; ↑AV conduction | ↑HR; ↑AV conduction; ↑contraction | ↓HR; ↓AV conduction; ↓contraction |
|  |  | Atropine (DOC): AV block, bradycardia (max. 3 mg). Low-dose atropine <0.5 mg → s/e: bradycardia | 1. Epinephrine: bradycardia (in children), cardiac arrest. 2. Dobutamine: acute CHF | β-blockers (DOC): atrial fibrillation/flutter (for rate control); HOCM; aortic dissection |
| **Bladder detrusor** | Contraction (M₃ +) | Relaxation (M₃ −) | Relaxation (β₃ +); bladder sphincter contracts (α₁) | — |

**Abbreviations:** SABA = short acting beta agonist; LABA = long acting beta agonist; vLABA = very long acting beta agonist.

### Bladder detrusor

**Parasympathomimetic:**
- Bethanechol, neostigmine:
  - Post-op urinary retention.
  - Bladder atony/overflow incontinence.

**Parasympatholytic — overactive bladder (urge incontinence):**
- Fesoterodine.
- Darifenacin.
- Oxybutynin.
- Solifenacin.
- Tolterodine.
- Trospium (× BBB).
- S/e: dementia (via M₁); least in darifenacin/solifenacin, trospium.

**Sympathomimetic:**
- Overactive bladder (urge incontinence): **Mirabegron (DOC)** (β₃ agonist).
- Stress incontinence: **Duloxetine** (SNRI: α₁ +).

### Skeletal muscles

| Parasympathomimetic | Parasympatholytic | Sympathomimetic | Sympatholytic |
|---|---|---|---|
| Contraction | Relaxation | Contraction | Relaxation |
| Edrophonium (DOC): Tensilon test for diagnosis of myasthenia gravis (MG); myasthenic vs cholinergic crisis (diagnosis) | NDMR (NM receptor blocker): muscle relaxants | β₂ agonists: tremor (s/e); clenbuterol: performance enhancer (banned) | β-blockers: ↓exercise tolerance (fatigue; avoid in athletes) |
| Neostigmine: Dx & Rx of MG; cobra bite; NDMR reversal | Pre-medication atropine before edrophonium/neostigmine: prevent muscarinic s/e |  |  |
| Pyridostigmine (DOC): management of MG |  |  |  |

## Drug action on blood vessels

|  | Sympathomimetic | Sympatholytic |
|---|---|---|
| **MOA** | Vasoconstriction (α-agonist) | Vasodilation (α-blocker) |
| **Spinal anaesthesia-induced hypotension** | **DOC:** ↓HR → ephedrine; normal HR → phenylephrine | — |
| **Pre-op HTN in pheochromocytoma** | — | **DOC:** phenoxybenzamine (oral α−); followed by β-blocker (prevents arrhythmia) |
| **Postural hypotension** | — | **DOC:** midodrine |
| **Phentolamine (IV)** | — | DOC: cheese reaction; clonidine withdrawal HTN; intra-op HTN in pheochromocytoma |
| **Cardiogenic, septic, neurogenic shock (NGS)** | Norepinephrine IV (DOC); NGS: add atropine (d/t ↓HR) | — |
| **Pheochromocytoma** | Nicardipine: oral → pre-op HTN; IV → intra-op HTN | — |
| **Anaphylactic shock** | Epinephrine (DOC): IM 0.3–0.5 mg (1:1000 dilution) | — |
| **HTN with BPH** | — | α₁−: terazosin, doxazosin, prazosin (DOC: scorpion bite); BPH DOC (α₁a−): tamsulosin, silodosin |
| **Other** | β-blockers: HTN in young age (↓renin) | — |

## Drug action on GIT

|  | Parasympathomimetic | Parasympatholytic |
|---|---|---|
| **MOA** | ↑HCl secretion; ↑contraction | ↓HCl secretion; ↓contraction |
| **Uses** | Neostigmine: gastroparesis; post-operative ileus | Pirenzepine, telenzepine: peptic ulcer disease (not used); antispasmodics: glycopyrrolate, dicyclomine (M/c), scopolamine |

## Side Effects of Drugs

| Drugs | Symptoms | Treatment |
|---|---|---|
| **Cholinergic poisoning** | Miosis: pin-point pupil (M/c); ↑salivation, sweating; involuntary urination/defecation; bradycardia | **OP poisoning:** atropine (DOC) + pralidoxime (most specific; AChE reactivator). Atropine only: carbamate poisoning. Normalised respiratory secretions: most specific. |
| **Anticholinergic poisoning (atropine, datura)** | Mydriasis; dry mouth; urine retention/constipation; tachycardia; hyperthermia, dry skin | **DOC: physostigmine** |
| **β-blockers** | Bronchospasm; bradycardia; insomnia, nightmares; blocks hypoglycemia symptoms; exercise intolerance | **Glucagon** (source of cAMP for the heart) |
| **α-blockers** | Postural hypotension; ejaculation abnormality; floppy iris | — |

## β-blockers

### Cardioselective β-blockers

**Mr. BEAN Cardiologist**

- 2nd > 3rd generation.
- Metoprolol.
- Betaxolol, Bisoprolol.
- Esmolol.
- Atenolol, Acebutolol.
- **Nebivolol:** most cardioselective, antioxidant action +.
- Celiprolol.

### β-blockers with additional properties

1. **α-blockers (vasodilatation):** Carvedilol, Labetalol (M/c).
2. **NO release:** Nebivolol.
3. **Calcium channel blocker:** Carvedilol.

### Important β-blockers

| Key feature | β-blocker |
|---|---|
| Longest acting | Nadolol |
| Shortest acting | Landiolol > esmolol |
| Antioxidant | Nebivolol, Carvedilol |
| Most cardioselective | Nebivolol |
| Partial agonist | Penbutolol, Pindolol, Acebutolol |
| Paralyses cell membrane (sodium channel −) | Propranolol, Metoprolol |

> 3rd generation β-blockers → vasodilation.

## Physiological Effects of Autonomic Drugs

### Effect of Catecholamines on HR

![Effect of catecholamines on HR](assets/ANS_Effect_of_catecholamines_on_HR.png)

- Isoprenaline (↑↑ HR).
- Epinephrine (↑ HR).
- Dobutamine (normal HR).
- Norepinephrine (reflex bradycardia via vagus).

**Note:** NE with atropine/transplanted heart = ↑HR.

### Dopamine

**Use similar to NE but s/e: ↑↑HR.**

Dose-dependent action (continuous IV infusion):

| Dose (mcg/kg/min) | Effect (Receptor) |
|---|---|
| >0–2 | Diuresis (D₁) |
| >2–10 | ↑Contraction of heart (β₁) |
| >10 | Vasoconstriction (α₁) |

### Effect on Blood Pressure

#### Dale’s phenomenon

**Threshold concentration of epinephrine for α₁ > β₂.**

![Dale’s phenomenon](assets/ANS_Dales_phenomenon.png)

**Biphasic response:** initial high concentration → ↑BP (α₁ mediated); later low concentration → ↓BP (β₂ mediated).

#### Vasomotor reversal of Dale

- Epinephrine + α-blocker in living system.
- Only ↓BP due to unopposed β₂ action.

![Vasomotor reversal of Dale](assets/ANS_Vasomotor_reversal_of_Dale.png)

#### Vasomotor re-reversal of Dale

- Epinephrine + β-blocker in living system.
- Steep ↑BP due to unopposed α₁ action.

![Vasomotor re-reversal of Dale](assets/ANS_Vasomotor_re_reversal_of_Dale.png)

### Epinephrine dilution

| Dilution | Route of administration |
|---|---|
| 1:1000 | S/C; IM; endotracheal |
| 1:10,000 | IV; intraosseous; intracardiac (not used) |
| 1:100,000 | Local vasoconstriction |
| 1:100,000 or 1:200,000 | Local (with lignocaine) |

## Anti-glaucoma Drugs

| Drug | MOA | Use | Side effects & contraindications |
|---|---|---|---|
| **Prostaglandin analogs**: Latanoprost, Bimatoprost | ↑Uveoscleral outflow | DOC: open-angle glaucoma (OAG) | Iris pigmentation, trichomegaly, dry/sandy eyes, cystoid macular edema; C/i: uveitis/herpetic keratitis |
| **β-blockers**: Timolol, metipranolol, levobunolol, carteolol; Betaxolol preferred in asthma/COPD | ↓Aqueous production | 2nd line: open-angle glaucoma | Timolol: NLD obstruction; metipranolol: granulomatous anterior uveitis; C/i: systemic β-blockers (total conduction block) |
| **Epinephrine, dipivefrin** | ↓Aqueous production | Open-angle glaucoma (↓use) | Ocular allergy; black pigmentation of conjunctiva |
| **α₂+**: Apraclonidine, Brimonidine | ↓Aqueous production | Open-angle glaucoma | Apraclonidine: lid retraction, mydriasis, conjunctival blanching; Brimonidine (crosses BBB): apnea in neonates, drowsiness, hypotension |
| **Miotic agents**: Pilocarpine, Physostigmine, Echothiophate, Carbachol | ↑Trabecular outflow | Pilocarpine (DOC): closed-angle glaucoma | Common s/e: brow ache, accommodation spasm, retinal detachment; echothiophate: iris cysts; echothiophate/physostigmine: cataract |
| **Carbonic anhydrase −**: oral/IV acetazolamide; topical brinzolamide | ↓Aqueous production | Acetazolamide: acute congestive glaucoma; Brinzolamide: OAG | — |
| **Rho kinase −**: Netarsudil | ↑Trabecular outflow | Open-angle glaucoma | Conjunctival hyperemia; corneal verticillata (rare) |
