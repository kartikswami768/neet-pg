PHARMACOLOGY — MARROW WORLD OF REVISION (2025)

Contents:
- 00_Content.md
- 01_General_Pharmacology.md
- 02_Autonomic_Nervous_System.md
- 03_CVS.md
- 04_Kidney.md
- 05_CNS.md
- 06_Antimicrobial_Drugs_Part_1.md
- 07_Antimicrobial_Drugs_Part_2.md
- 08_Drugs_Acting_on_Endocrine_System.md
- 09_Autacoids.md
- 10_Drugs_Acting_on_RS_GIT_Blood.md
- 11_Immunomodulators_and_Anticancer_Drugs.md
- assets/ — all image assets referenced by the Markdown files

All image embeds use relative paths of the form assets/<filename> so the files work when the folder is opened as an Obsidian vault/folder.

Common Obsidian properties on all Markdown files:
- title
- aliases
- subject
- section
- type
- source
- tags

No page-number properties are included.
