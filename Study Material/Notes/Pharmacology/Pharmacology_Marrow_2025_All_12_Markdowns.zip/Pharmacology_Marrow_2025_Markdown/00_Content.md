---
title: "Pharmacology — Contents"
aliases:
  - "Pharmacology Contents"
subject: "Pharmacology"
section: "Contents"
type: "index"
source: "Marrow — World of Revision — Pharmacology (2025)"
tags:
  - pharmacology
  - contents
  - index
---

# Contents

# Pharmacology

## General Pharmacology : Part 1

- Types of drugs
- Pharmacokinetics and pharmacodynamics
- Drug absorption
- Drug distribution
- Drug metabolism
- Drug excretion

## General Pharmacology : Part 2

- Parameters of pharmacodynamics
- Dose - response curve (DRC)
- Drug receptor interaction
- Receptors
- Drug safety
- Adverse drug reactions
- Therapeutic drug monitoring
- Miscellaneous

## Drugs Acting on Autonomic Nervous System

- Neurotransmitters of ANS
- Systemic ANS drugs action
- Side effects of drugs
- β-blockers
- Physiological effects of autonomic drugs
- Anti-glaucoma drugs

## Drugs Acting on CVS

- Anti-arrhythmic drugs
- Heart failure drugs
- Hypertension
- Anti-anginal drugs
- Side effects
- Hypolipidemic drugs

## Drugs Acting on Kidney

- Diuretics
- Vasopressin related drugs

## Drugs Acting on CNS

- Anti-epileptic drugs
- Psychiatric drugs
- Degenerative disorders
- Miscellaneous
- Migraine
- Sleep disorders
- Opioids
- MX of dependencies
- Side effects of CNS drugs
- Extrapyramidal symptoms
- Lithium
- Side effects of opioids

## Antimicrobial Drugs : Part 1

- Classification
- Cell wall synthesis inhibitors
- Protein synthesis inhibitors
- Anti-folate drugs
- Fluoroquinolones
- Side effects

## Antimicrobial Drugs : Part 2

- Non-retroviral drugs
- Antiretroviral drugs
- Antifungal drugs
- Antihelminthic drugs
- Antiprotozoal drugs
- Antitubercular drugs
- Antileprosy drugs

## Drugs Acting on Endocrine System

- Antidiabetic drugs
- GnRH related drugs
- Drugs for contraception
- Growth hormone related drugs
- Drugs used in osteoporosis
- Steroid hormone related drugs
- Thyroid related drugs

## Autacoids

- Antihistaminics
- NSAIDs
- Prostaglandin analogs
- Disease modifying anti-rheumatoid drugs (DMARDs)
- Anti-gout drugs

## Drugs Acting on RS, GIT and Blood

- Antiasthmatic drugs
- Antitussives
- Drugs used in peptic ulcer disease (PUD)
- Prokinetics
- Antiemetics
- Laxatives
- Anti-diarrhoeal agents
- Antiaggregants
- Anticoagulants
- Fibrinolytics/Thrombolytics
- Hematopoietic agents

## Immunomodulators and Anticancer Drugs

- Immunosuppressants
- Solid tumors
- Breast cancer
- Leukemia
- Side effects and antidotes of anti-cancer drugs
- Miscellaneous anti-cancer drugs
