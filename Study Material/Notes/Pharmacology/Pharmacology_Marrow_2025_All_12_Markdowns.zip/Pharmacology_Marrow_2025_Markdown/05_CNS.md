---
title: "Drugs Acting on CNS"
aliases:
  - "CNS Pharmacology"
  - "Central Nervous System Pharmacology"
subject: "Pharmacology"
section: "Drugs Acting on CNS"
type: "study-notes"
source: "Marrow — World of Revision — Pharmacology (2025)"
tags:
  - pharmacology
  - central-nervous-system
  - CNS
  - antiepileptics
  - psychiatry
  - opioids
---

# Drugs Acting on CNS

## Anti-Epileptic Drugs

| Seizure/condition | DOC / drug | Notes |
|---|---|---|
| **GTCS** | Valproate | −Ca²⁺ & Na⁺ channels; ↑GABA |
| **Myoclonic seizure** | Valproate | — |
| **Absence seizure** | Ethosuximide > Valproate | — |
| **Partial seizure** | Carbamazepine | — |
| **Rolandic epilepsy** | Carbamazepine | — |
| **Mixed seizure syndrome** | Valproate | Lennox-Gastaut syndrome (LGS); Dravet syndrome (DS) |
| **Seizure in neonates** | Phenobarbital | Protective against ischemia |
| **Alcohol withdrawal seizures** | Diazepam; Lorazepam | Lorazepam safe in liver failure |
| **Status epilepticus** | 1. Lorazepam | 2. In children (with no IV access): intranasal midazolam |
| **Febrile seizures** | Intranasal midazolam >> rectal diazepam | — |
| **Infantile spasm with tuberous sclerosis (TS)** | Vigabatrin | −GABA transaminase |
| **Infantile spasm without TS / Salaam spasm / West syndrome** | ACTH | — |

**Note:** Valproate has no action on glutamate.

### Newer drugs

- Cannabidiol: uses LGS, TS, DS.
- Rufinamide: use LGS (add-on drug).
- Lacosamide: MOA — slow inactivation of Na⁺ channels.

## In Pregnancy

**Teratogenicity:**

- Min: Levetiracetam (DOC) < Lamotrigine.
- Max: Valproate:
  - A/w neural tube defects.
  - Category D drug.

## Psychiatric Drugs

### Mania

| Condition | DOC / drug |
|---|---|
| Acute mania | Atypical antipsychotics (Aripiprazole/Brexpiprazole) |
| Mania in pregnancy — 1st trimester | Aripiprazole |
| Mania in pregnancy — 2nd/3rd trimester | Lithium |
| Mania prophylaxis | Lithium |
| Hypnic headache | Lithium |
| Bipolar disorder | Lithium (can ↑ or ↓ BDNF) |
| Rapid cycler: BPAD with >4 episodes of mania/depression in 1 yr | Valproate |

### Teratogenicity in BPAD

- Min: Lamotrigine.
- Max: Valproate >> Lithium.

### Female on valproate conceives

```mermaid
flowchart TD
    A[Female on valproate conceives] --> B[Continue valproate<br/>(Do NOT stop/change the drug)]
    B --> C[Therapeutic drug monitoring]
    C --> D{History of NTD?}
    D -->|No h/o NTD| E[Folic acid 400 mcg]
    D -->|H/o NTD / previous pregnancy| F[Folic acid 4000 mcg]
```

## Depressive Disorders

| Condition / drug | Features / notes |
|---|---|
| **Depression** | 1st line: SSRI/SNRI; early morning dose; add benzodiazepine (≥1 month) to prevent anxiety/insomnia |
| **Withdrawal** | Not seen with SSRI: Fluoxetine (longest acting: 10 days). Seen with SSRI: Paroxetine (shortest acting); SNRI: Venlafaxine |
| **With insomnia or erectile dysfunction** | Mirtazapine: NaSSA (noradrenergic & specific serotonergic antidepressants); night dose (sedation); H₁− & 5-HT₂− |
| **With suicidal tendency** | Mnemonic: Life Can End → Lithium; Clozapine; ECT (best) |

### Novel antidepressants

- Vilazodone.
- Vortioxetine (MSAA: multiple serotonin agonist & antagonist).
- Ketamine (intranasal).
- Zuranolone (oral).
- Brexanolone (IV).

**DOC for postpartum depression:**

- Zuranolone (oral).
- Brexanolone (IV).

## Degenerative Disorders

### Parkinson’s Disease

| Effect of disease on lifestyle | Management | S/e |
|---|---|---|
| **Minimal** | 1. No drug. 2. MAO-B − (DOC): selegiline/rasagiline; TOC in young-onset Parkinson’s. 3. NMDA −: amantadine | Amantadine: ankle edema; livedo reticularis |
| **Significant** | Age <65: D₂ agonist (DOC): pramipexole, ropinirole. Age ≥65: levodopa | Fatigue; compulsive gambling/sexual activity |

**Levodopa:**
- Used with carbidopa:
  - Peripheral DOPA decarboxylase.
- On-off phenomenon:
  - D/t fluctuating dopamine.
  - Rx:
    - COMT −: entacapone.
    - MAO-B −: safinamide.
    - D₂ agonists.
- Dyskinesia:
  - Rx DOC: amantadine.
- Orthostatic hypotension.
- Psychosis:
  - Rx DOC: pimavanserin.
  - Also an absolute C/i.
- Angle closure glaucoma:
  - Also a relative C/i.
- Rotigotine: transcranial patch.

> **Note:** Drugs causing ankle edema: Amantadine, Amlodipine.

### Amyotrophic Lateral Sclerosis

**Aim of management:**

1. Inhibit disease progression.
2. Reverse muscle spasticity.

**Drugs: (REST + Bed)**

- Riluzole: DOC.
- Edaravone: 2nd line.
- Sodium phenylbutyrate taurursodiol (SPT): 2nd line.
- Tofersen: only in SOD-1 gene mutation.
- Baclofen (GABA-B +): neuro degeneration + muscle relaxant.

### Alzheimer’s Disease

**Management:**

- AChE −: DOC.
  - Donepezil (oral).
  - Rivastigmine (oral/patch).
- NMDA −: Memantine.
  - Add-on drug.
  - Used in moderate–severe Alzheimer’s.
- New drugs:
  - Aducanumab.
  - Lecanemab.
  - Donanemab.

## Miscellaneous

| Disorder | DOC | MOA / side effects |
|---|---|---|
| Trigeminal neuralgia | Carbamazepine | — |
| Postherpetic neuralgia | Pregabalin/Gabapentin | α₂δ₁ subunit of presynaptic voltage-gated Ca²⁺ channel |
| Pain due to spinal cord injury | Pregabalin/Gabapentin | α₂δ₁ subunit of presynaptic voltage-gated Ca²⁺ channel |
| Restless leg syndrome | Pregabalin/Gabapentin | α₂δ₁ subunit of presynaptic voltage-gated Ca²⁺ channel |
| Psychosis | Weight-neutral atypical antipsychotics: aripiprazole, brexpiprazole, cariprazine, ziprasidone | Partial agonist at D₂ & 5HT₂ |
| Psychosis — last line | Olanzapine; Clozapine (DOC for resistant psychosis) | — |
| ADHD | Methylphenidate | Worsens tics; ↑risk of abuse |

## Migraine

### Prophylaxis

- **Propranolol (DOC).**
- Topiramate (toxic).

### Treatment

1. **5-HT₁B/1D +:**
   - DOC oral: **Rizatriptan** (fastest oral drug) > sumatriptan.
   - S/C: **Sumatriptan** (overall fastest).
   - C/i: angina (d/t vasoconstriction).
2. **New drugs:**
   - 5-HT₁F +: Lasmiditan (for acute attack).
   - CGRP (calcitonin gene-related peptide) −:
     - Eptinezumab.
     - Fremanezumab.
     - Galcanezumab.
   - CGRP receptor −:
     - Erenumab.
     - Olcegepant.
     - Rimegepant.
   - Oral for either Rx/prophylaxis.
   - S/C, prophylaxis.
3. **Ergotamines:**
   - Ergotism: very potent vasoconstrictor → gangrene of organs with end arteries.

## Sleep Disorders

### Narcolepsy

- **Modafinil: DOC.**
- MOA: ↑dopamine → ↑wakefulness.

### Insomnia

- **Z-compounds: DOC**
  - Zolpidem.
  - Zaleplon.
  - Zopiclone.
- C/i in drug abusers.

### DORA (Dual orexin receptor antagonist)

- Suvorexant.
- DOC in h/o drug abuse.
- Sleep induction and maintenance.

### Other sleep/ADHD-related notes

| Disorder | DOC | MOA / note |
|---|---|---|
| ADHD with Tourette syndrome | Clonidine | Withdrawal HTN (d/t α₂ downregulation) |
| ADHD with family h/o drug abuse | Atomoxetine | Selective norepinephrine reuptake − |
| Tics a/w Tourette syndrome | Tetrabenazine | — |
| Huntington’s chorea | Tetrabenazine | — |

### Melatonin agonist

- Ramelteon.
- Less effective.
- Less dependence.
- Only sleep induction.

## Opioids

**Note:**

- Constipation.
- Convulsion.
- Constriction of pupil (miosis).

| Condition | Drug |
|---|---|
| Labour analgesia | DOC: Morphine (other uses: MI, cancer); pethidine |
| Opioid induced constipation | Methyl naltrexone: DOC |
| Post-op ileus | Alvimopan: DOC |
| Post anesthetic chills | Pethidine; Tramadol |
| Opioid contraindicated in MI | Pentazocine |
| Opioid toxicity | Naloxone (IV emergency; I/N ambulatory) |

### Opioids with specific properties

| Opioid | Property |
|---|---|
| Buprenorphine | Partial agonist at μ & antagonist at κ |
| Pentazocine | Partial agonist at μ & full agonist at κ |
| Tramadol | 5-HT & NE reuptake − |
| Pethidine | MAO − effect |
| Methadone | QT prolongation |

### Other drugs / conditions

- Rett syndrome: Trofinetide.
- Friedreich's ataxia: Omaveloxolone.

> No tolerance for these side effects.

## Mx of Dependencies

### Alcohol Dependence

**FDA approved:**

1. **Aversive Rx: Disulfiram.**
   - MOA: − aldehyde dehydrogenase → ↑acetaldehyde (toxic).
   - Prerequisites:
     - Motivated patient.
     - Abstinence of 12 hours.
2. **Anti-craving drugs:**
   - Naltrexone (DOC): μ receptor ↓euphoric effect.
   - Acamprosate.

**Non-FDA approved:**

- Benzodiazepines.
- Clonidine.
- Topiramate.
- Baclofen.

### Smoking Dependence

**First line Rx:**

1. **Drugs:**
   - Bupropion: antidepressant.
   - Varenicline:
     - Partial agonist at nicotinic receptor (α₄β₂).
     - Most effective.
2. **Nicotine replacement:**
   - Nasal spray:
     - Needs prescription (Schedule H).
     - Most effective.
   - Patch.
   - Gums.
   - Lozenge.

**Second line:**

- TCA.
- Clonidine.
- Cytisine.

## Side Effects of CNS Drugs

### Anti-Epileptic Drugs

#### Valproate

**Mnemonic: Tab VALPROIC**

- **Tab:** tremor, teratogenic (max).
- Vomiting & nausea.
- Alopecia.
- Liver toxicity (C/i in children <2 years).
- Pancreatitis.
- Rash.
- Obesity: PCOS.
- Increase ammonia.
- Carnitine: antidote for hepatotoxicity & hyperammonemia.

#### Phenytoin

**Mnemonic: HYDANTOIN**

- Hirsutism.
- Hyperplasia of gum.
- Lymphadenopathy.
- Diplopia.
- ↓Vit D (hypocalcemia).
- Ataxia → therapeutic drug monitoring & adjust dosage.
- Nystagmus.
- Teratogenic: facial clefts.
- Osteomalacia.
- Increased bleeding in newborn (↓Vit K).
- Neutropenia, megaloblastic anemia.

#### Carbamazepine

**Mnemonic: HEADS**

- Hyponatremia (d/t SIADH):
  - Delayed s/e.
  - M/c in elderly.
- Hypersensitivity:
  - Eosinophilia.
  - Aplastic anemia.
  - Agranulocytosis.
- Ataxia.
- Diplopia.
- SJS: HLA-B1502 gene.

**Oxcarbazepine/Eslicarbazepine:**
- ↓Hypersensitivity.
- ↑Hyponatremia.

#### Lamotrigine

- No action on GABA.
- SJS (rash): started at low dose.

#### Topiramate

**Mnemonic: RAM ate less**

- Renal stones.
- Angle closure glaucoma.
- Metabolic acidosis.
- Weight loss.
- Use: obesity.

### Antidepressants

| Drug/class | Receptor/effect | Side effects / notes |
|---|---|---|
| **SSRI/SNRI** | 5-HT₂ + (brain, spinal cord) | Anxiety; insomnia; vivid dreams; erectile dysfunction; delayed ejaculation; anorgasmia |
|  | 5-HT₃ + | Nausea, vomiting |
|  | 5-HT₄ + | Loose stools |
| **TCA** | Muscarinic − | C/i in glaucoma, BPH; constipation, dry mouth; urine retention, mydriasis |
|  | 5-HT, H₁ − | Obesity, sedation |
|  | α₁ − | Postural hypotension |
| **Mirtazapine** | H₁ − | Sedation, obesity |
| **Bupropion** | — | Seizure, max anxiety |
| **MAO −** | — | Cheese reaction; serotonin syndrome |
| **Trazodone** | 5-HT₂ − | Priapism; 2° use: premature ejaculation (dapoxetine) |

**Toxicity:**
- DOC: bicarbonate.
- Cause of death: arrhythmia.

**Rx:**
- Phentolamine.
- Lorazepam.
- Cyproheptadine (DOC).

## Antipsychotics

**Affinity towards a receptor ∝ s/e at that receptor.**

### Zero Side Effects Seen With

**New drug:** Xanomeline (+ M₁ & M₄, no action on D₂).

**Others — mnemonic ABCZ:**

- Aripiprazole.
- Brexpiprazole.
- Cariprazine.
- Ziprasidone.

| Receptor | Side effects | Drugs with ↑affinity & ↑s/e |
|---|---|---|
| D₂ receptor − | EPS; hyperprolactinemia | Atypical: Risperidone; Typical: Haloperidol |
| Muscarinic − | Constipation; dry mouth; mydriasis, urine retention | — |
| H₁ − | Sedation | Clozapine > Olanzapine |
| H₁ & 5-HT − | Obesity | — |
| α₁ − | Postural hypotension; metabolic s/e: dyslipidemia & hyperglycemia | — |

## Extrapyramidal Symptoms

| EPS | Symptom | Cause | DOC |
|---|---|---|---|
| **Akathesia (M/c)** | Restlessness | Unknown | Beta blockers: DOC; benzodiazepines |
| **Acute dystonia (earliest)** | Abnormal posturing; facial grimacing | D₂ −; metoclopramide injection | Anticholinergics: DOC — trihexyphenidyl (benzhexol), benztropine, biperiden; antihistaminics: promethazine |
| **Parkinsonism** | Tremor; bradykinesia | D₂ − | — |
| **Tardive dyskinesia (most late)** | Facial dyskinesia: tongue protrusion, lip smacking; limb dyskinesia: piano finger movement, foot tapping | D₂ upregulation | VMAT-2 −: valbenazine, deutetrabenazine |
| **Neuroleptic malignant syndrome (most lethal)** | Muscle rigidity; hyperthermia; ANS instability | D₂ − | Dantrolene (DOC; −RyR); bromocriptine + D₂ (most specific drug) |

## Lithium

### Side Effects

**Mnemonic: HOTHEAD**

- Hypothyroidism (−TSH-R).
- Obesity.
- Tremor:
  - Fine: normal plasma concentration.
  - Coarse: toxicity.
- Hypercalcemia (↑PTH).
- Ebstein anomaly: C/i in pregnancy (1st trimester).
- Acne.
- Diabetes insipidus (thirst): Rx DOC **Amiloride**.

### Interactions

- Thiazide > K⁺ sparing diuretic.
- Vomiting, diarrhea.
- Fasting.
- RAAS −.
- NSAIDs.
- Mannitol ↑excretion of Li.
- Li + NDMR ↑↑effect of NDMR (but Li not stopped pre-op).

**Note:**
- ↓s. Na → ↑Li tubular reabsorption.
- ↓filtration of Li.

### Therapeutic Drug Monitoring

- Sample taken 12 hrs after last dose + 6th day of Rx (half-life: 24 hrs).
- Doses (mEq/L):
  - Prophylaxis of mania: 0.6–1.
  - Acute mania: 1–1.5.
  - Toxicity: >1.5.
  - >4: dialysis (TOC).

## Side Effects of Opioids

### μ Receptor Effects

**Mnemonic: MUSCARINE**

- Miosis.
- Urine retention.
- Sedation.
- Constipation, convulsion.
- Analgesia.
- Respiratory depression.
- Increase muscle rigidity.
- No bile flow d/t contraction of sphincter of Oddi.
- Euphoria.

> **Opposite effects → withdrawal symptoms.**

**Note:**
- Worsening of biliary colic (Morphine).
- Used in Rx of biliary colic (Pethidine).
